package es.jripoll.ioc.annotationconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IocAnnotationConfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
